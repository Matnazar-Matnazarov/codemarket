Kompyuter qismlari sayti
